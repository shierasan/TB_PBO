import java.util.Scanner;
import services.BookingSystem;

// Program utama untuk menjalankan sistem booking
public class Main {
    @SuppressWarnings("UseSpecificCatch")
    public static void main(String[] args) {
        BookingSystem bookingSystem = new BookingSystem();
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Booking System ===");

        try {
            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Create Booking");
                System.out.println("2. Read Bookings");
                System.out.println("3. Update Booking");
                System.out.println("4. Delete Booking");
                System.out.println("5. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter customer name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter customer phone: ");
                        String phone = scanner.nextLine();
                        System.out.print("Enter sport court (Badminton, Futsal, Basketball): ");
                        String court = scanner.nextLine();
                        System.out.print("Enter duration (hours): ");
                        int duration = scanner.nextInt();
                        bookingSystem.createBooking(name, phone, court, duration);
                    }
                    case 2 -> bookingSystem.readBookings();
                    case 3 -> {
                        System.out.print("Enter booking ID to update: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        System.out.print("Enter new sport court: ");
                        String court = scanner.nextLine();
                        bookingSystem.updateBooking(id, court);
                    }
                    case 4 -> {
                        System.out.print("Enter booking ID to delete: ");
                        int id = scanner.nextInt();
                        bookingSystem.deleteBooking(id);
                    }
                    case 5 -> {
                        System.out.println("Exiting...");
                        return;
                    }
                    default -> System.out.println("Invalid option.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
