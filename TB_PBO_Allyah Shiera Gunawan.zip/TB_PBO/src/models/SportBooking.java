package models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Kelas abstrak untuk properti dasar dari sebuah booking
public abstract class SportBooking {
    // URL koneksi ke database
    protected final String databaseUrl = "jdbc:sqlite:db_tb_pbo";

    // Metode untuk koneksi ke database
    protected Connection connectDatabase() throws SQLException {
        return DriverManager.getConnection(databaseUrl);
    }
}
