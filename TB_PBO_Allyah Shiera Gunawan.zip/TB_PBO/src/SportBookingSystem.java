import java.util.Scanner;
import services.BookingSystem;

public class SportBookingSystem {
    @SuppressWarnings("UseSpecificCatch")
    public static void main(String[] args) {
        BookingSystem system = new BookingSystem();
        @SuppressWarnings("resource")
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Create Booking\n2. View Bookings\n3. Update Booking\n4. Delete Booking\n5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1 -> {
                        System.out.print("Customer Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Phone: ");
                        String phone = scanner.nextLine();
                        System.out.print("Sport Court (Badminton/Futsal/Basketball): ");
                        String court = scanner.nextLine();
                        System.out.print("Duration (in hours): ");
                        int duration = scanner.nextInt();
                        system.createBooking(name, phone, court, duration);
                    }
                    case 2 -> system.readBookings();
                    case 3 -> {
                        System.out.print("Booking ID to update: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("New Sport Court (Badminton/Futsal/Basketball): ");
                        String newCourt = scanner.nextLine();
                        system.updateBooking(id, newCourt);
                    }
                    case 4 -> {
                        System.out.print("Booking ID to delete: ");
                        int id = scanner.nextInt();
                        system.deleteBooking(id);
                    }
                    case 5 -> {
                        System.out.println("Exiting...Bye!");
                        return;
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
