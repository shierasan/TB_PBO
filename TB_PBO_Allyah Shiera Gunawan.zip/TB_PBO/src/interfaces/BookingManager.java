package interfaces;

import java.sql.SQLException;

// Interface untuk mendefinisikan operasi CRUD
public interface BookingManager {
    // Metode untuk membuat booking baru
    void createBooking(String customerName, String customerPhone, String sportCourt, int duration) throws SQLException;

    // Metode untuk membaca semua data booking
    void readBookings();

    // Metode untuk memperbarui data booking berdasarkan ID
    void updateBooking(int bookingId, String newSportCourt) throws SQLException;

    // Metode untuk menghapus data booking berdasarkan ID
    void deleteBooking(int bookingId) throws SQLException;
}
