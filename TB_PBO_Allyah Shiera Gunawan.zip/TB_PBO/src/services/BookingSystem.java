package services;

import interfaces.BookingManager;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import models.SportBooking;

public class BookingSystem extends SportBooking implements BookingManager {
    private final List<String> availableCourts;

    public BookingSystem() {
        this.availableCourts = Arrays.asList("Badminton", "Futsal", "Basketball");
        createTableIfNotExists(); // Buat tabel di MySQL (jika belum ada)
    }

    // Metode untuk koneksi ke MySQL
    @SuppressWarnings("override")
    protected Connection connectDatabase() {
        Connection conn = null;
        try {
            // Load driver JDBC MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Buat koneksi ke database
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/db_tb_pbo", // Ganti dengan nama database Anda
                "root", // Default username (XAMPP)
                ""      // Default password (XAMPP)
            );
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found: " + e.getMessage());
        }
        return conn;
    }

    private void createTableIfNotExists() {
        String sql = """
                CREATE TABLE IF NOT EXISTS bookings (
                id_booking INT AUTO_INCREMENT PRIMARY KEY,
                customer_name VARCHAR(100) NOT NULL,
                customer_phone VARCHAR(15) NOT NULL,
                sport_court VARCHAR(50) NOT NULL,
                date DATETIME NOT NULL,
                duration INT NOT NULL
                )
                """;
        try (Connection conn = connectDatabase();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Error creating table: " + e.getMessage());
        }
    }

    // Implementasi CRUD sesuai interface
    @Override
    public void createBooking(String customerName, String customerPhone, String sportCourt, int duration)
            throws SQLException {
        if (!availableCourts.contains(sportCourt)) {
            throw new IllegalArgumentException("Invalid sport court. Choose from: " + availableCourts);
        }

        String currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

        String sql = """
                INSERT INTO bookings (customer_name, customer_phone, sport_court, date, duration)
                VALUES (?, ?, ?, ?, ?)
                """;

        try (Connection conn = connectDatabase();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, customerName.trim());
            pstmt.setString(2, customerPhone.trim());
            pstmt.setString(3, sportCourt);
            pstmt.setString(4, currentDate);
            pstmt.setInt(5, duration);
            pstmt.executeUpdate();
            System.out.println("Booking created successfully!");
        }
    }

    @Override
    public void readBookings() {
        String sql = "SELECT * FROM bookings";
        try (Connection conn = connectDatabase();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id_booking") +
                        ", Name: " + rs.getString("customer_name") +
                        ", Phone: " + rs.getString("customer_phone") +
                        ", Court: " + rs.getString("sport_court") +
                        ", Date: " + rs.getString("date") +
                        ", Duration: " + rs.getInt("duration") + " hours");
            }
        } catch (SQLException e) {
            System.out.println("Error reading bookings: " + e.getMessage());
        }
    }

    @Override
    public void updateBooking(int bookingId, String newSportCourt) throws SQLException {
        if (!availableCourts.contains(newSportCourt)) {
            throw new IllegalArgumentException("Invalid sport court. Choose from: " + availableCourts);
        }

        String sql = "UPDATE bookings SET sport_court = ? WHERE id_booking = ?";
        try (Connection conn = connectDatabase();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newSportCourt);
            pstmt.setInt(2, bookingId);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Booking updated successfully!");
            } else {
                System.out.println("Booking not found.");
            }
        }
    }

    @Override
    public void deleteBooking(int bookingId) throws SQLException {
        String sql = "DELETE FROM bookings WHERE id_booking = ?";
        try (Connection conn = connectDatabase();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, bookingId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Booking deleted successfully!");
            } else {
                System.out.println("Booking not found.");
            }
        }
    }
}